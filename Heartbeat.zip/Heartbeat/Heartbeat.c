/* Fehler.c */
#include <stdio.h>

int main() {
   float beats,age;
       printf("\n\tHeartbeater\n");
       printf("\nHeartbeats per Minute : ");
       scanf("%f",&beats);
       printf("Age in Years : ");
       scanf("%f",&age);
       printf("\nYour heart have beaten that many times since your birth : ");
       printf("%.0f ",beats * 60 * 24 * 365.25 * age);

    return(0);
}
