<!DOCTYPE html>
<html>
<head>

<title>Palindrome.com</title>

<meta charset="utf-8" />

<link href="inline.css" rel="stylesheet" type="text/css" />

<style>
*
{
padding:0px;
margin:0px;
}

html {

background-image: linear-gradient(90deg, white,darkgrey, black);
background-size: cover;
background-position: center center;
background-attachment: fixed;

}

header h1
{
text-align:center;
}

</style>

</head>

<body>

<header>

<h1>P A L I N D R O M E ---- C H E C K E R</h1>

</header>

    <form action="palindrom.php"  method="post">        
    <br> Write some random Words: <input type="text" name="word"/><br>  
    <button type="submit">Check</button> 
	<button type="reset">Reset</button>
    </form>  

</body>

</html>