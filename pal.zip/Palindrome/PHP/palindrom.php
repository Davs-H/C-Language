    <?php   
        if($_POST)  
        {  
	$word = $_POST['word'];
    //remove all spaces /*entfernt alle Leerfelder*/
    $word = str_replace(' ', '', $word); /*String-Replace*/

    //remove special characters /*entfernt Sonderzeichen*/
    $word = preg_replace('/[^A-Za-z0-9\-]/', '', $word); /*Pattern-Replace*/

    //change case to lower /*ignoriert Groß und Kleinschreibung*/
    $word = strtolower($word); /*String-to-lower*/

    //reverse the string /*Erlaubt Rückwärts-lesen*/
    $reverse = strrev($word); /*String-reverse*/

    if ($word == $reverse) {
        echo "<p>$word is a Palindrome</p>";
    } 
    else {
        echo "</p>$word is not a Palindrome</p>";  
            }  
    }     
?>  