		Palindrome-----PHP

-Dies Programm ermittelt die Vorw�rts und R�ckw�rtseingabe des Wort's


---------------------Anleitung---------------------

1. - Um das Dokument auf der Webseite anzeigen zu lassen braucht man folgende Programme:
Ein Webserver(Apache empfohlen), PHP(Software) [minimum], wenn man alles parat haben will, 
holt man sich XAMPP oder schaut online nach ein PHP-compiler.


------------------------------------Nur wenn man sich XAMPP holt------------------------------------------------------

2. Man f�hrt das XAMPP-setup durch und konfiguriert die Einstellungen damit PHP-dateien per Web angezeigt werden kann.

3. �ffnet per Localhost ie Datei Form.php indem ihr localhost/Form.php im http-suchverlauf eingibt.

4. Gibt das beliebige Wort ein.

5. Dann wird man automatisch zu der PHP-Seite palindrom.php weitergeleitet, wo das Ergebniss angezeigt wird.
