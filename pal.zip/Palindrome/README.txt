		Palindrome.exe


Mit diesen Programm kann herausgefunden werden ob ein Wort
Vorw�rts und R�ckw�rts gelesen werden kann, und damit k�nnte man �berpr�fen ob Hannah, Kiwik oder John ein Palindrom ist. 

beachten sie dabei das, dass Programm auf Gro� und Kleinschreibung achtet, 
selbst wenn das Wort eigentlich Palindrom ist, aber die Anfangs und das Endbuchstabe nicht die gleiche gr��e aufweisen.

Das Programm schlie�t sich nach 4 Eingabeversuchen, daher m�ssen sie nach den 4 versuchen dass Programm neustarten wenn ihnen das 
noch nicht gen�gt.

geschrieben wurde das Programm in C.

